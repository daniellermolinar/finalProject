//
//  QuestionBank.swift
//  FunWithFlags
//
//  Created by Victor on 2017-12-16.
//  Copyright © 2017 Victor. All rights reserved.
//

import Foundation

class QuestionBank{
    var list = [Question]()
    
    init() {
        list.append(Question(image: "flag1", questionText: "How did Daenerys Targaryen eventually hatch her dragon eggs?", choiceA: "A. In a lightning storm", choiceB: "B. In a frozen cave", choiceC: "C.  In a fireplace", choiceD: "D. In a funeral pyre", answer: 4))
        
        list.append(Question(image: "flag2", questionText: "How many eyes does the raven in Bran's dream have?", choiceA: "A. One", choiceB: "B. Two", choiceC: "C. Three", choiceD: "D. Four", answer: 3))
        
        list.append(Question(image: "flag3", questionText: "Which season were all the Stark children born during?", choiceA: "A. Winter", choiceB: "B. Summer", choiceC: "C. Autumn", choiceD: "D. Spring", answer: 2))
        
        list.append(Question(image: "flag4", questionText: "Who saves Sansa Stark during the Riot of King's Landing?", choiceA: "A. The Hound", choiceB: "B. Joffrey Baratheon", choiceC: "C. Tyrion Lannister", choiceD: "D. Petyr Balesh", answer: 1))
        
        list.append(Question(image: "flag5" , questionText: "How many kingdoms are in Westeros?", choiceA: "A. Three" , choiceB: "B. Nine" , choiceC: "C. Five" , choiceD: "D. Seven", answer: 4))
        
        list.append(Question(image: "flag15" , questionText: "Who were the Unsullied NOT instructed to kill in Astapor?", choiceA: "A. The Council" , choiceB: "B. The Soldiers" , choiceC: "C. The Men Holding Whips" , choiceD: "D. The Masters", answer: 1))
    }
}
