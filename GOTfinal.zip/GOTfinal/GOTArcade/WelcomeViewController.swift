//
//  WelcomeViewController.swift
//  FunWithFlags
//
//  Created by Danielle Molinar on 5/3/18.
//  Copyright © 2018 Victor. All rights reserved.
//

import UIKit
import AVFoundation

class Global {
    var nameVar = String()
    var pickerVar = String()
    var quizScore:Int = 0
}
let global = Global()

class WelcomeViewController: UIViewController {
        
        var player: AVAudioPlayer!
        
        @IBOutlet weak var photo: UIImageView!
        
        @IBOutlet weak var playButton: UIButton!
        
        @IBAction func play(_ sender: Any) {
            let path = Bundle.main.path(forResource: "dragon", ofType: "mp3")!
            let url = URL(fileURLWithPath: path)
            do {
                player = try AVAudioPlayer(contentsOf: url)
                player.prepareToPlay()
            } catch let error as NSError {
                print(error.description)
            }
            player.play()
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
            UIView.animate(withDuration: 5.0, animations: {
                self.photo.frame = CGRect(x:3, y: 196, width: 400, height: 380)
            })
                
            { (finished) in
                self.playButton.isHidden = false
            }
            
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        
}

