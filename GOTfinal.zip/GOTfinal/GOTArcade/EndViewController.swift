//
//  EndViewController.swift
//  FunWithFlags
//
//  Created by Danielle Molinar on 5/4/18.
//  Copyright © 2018 Victor. All rights reserved.
//

import UIKit

class EndViewController: UIViewController {

    
    @IBOutlet weak var thankYou: UILabel!
    
    @IBOutlet weak var picker: UILabel!
    
    override func viewWillAppear(_ animated: Bool){
        
        thankYou.text = "Thank you for playing, " + global.nameVar + "!!"
        picker.text = "Quiz Score: \(global.quizScore)"
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
