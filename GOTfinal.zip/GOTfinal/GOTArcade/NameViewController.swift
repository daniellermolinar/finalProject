//
//  NameViewController.swift
//  FunWithFlags
//
//  Created by Danielle Molinar on 5/4/18.
//  Copyright © 2018 Victor. All rights reserved.
//

import UIKit

class NameViewController: UIViewController, UITextFieldDelegate   {

    @IBOutlet weak var myName: UITextField!
    
    
    @IBAction func myButton(_ sender: Any) {
        global.nameVar = myName.text!
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       myName.delegate = self
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
